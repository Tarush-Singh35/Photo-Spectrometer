function varargout = beta1(varargin)
% BETA1 MATLAB code for beta1.fig
%      BETA1, by itself, creates a new BETA1 or raises the existing
%      singleton*.
%
%      H = BETA1 returns the handle to a new BETA1 or the handle to
%      the existing singleton*.
%
%      BETA1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BETA1.M with the given input arguments.
%
%      BETA1('Property','Value',...) creates a new BETA1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before beta1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to beta1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help beta1

% Last Modified by GUIDE v2.5 13-Jul-2016 17:43:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @beta1_OpeningFcn, ...
                   'gui_OutputFcn',  @beta1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before beta1 is made visible.
function beta1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to beta1 (see VARARGIN)

% Choose default command line output for beta1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
clear all;
global a;
global seg;
global seg2;
seg = 1;
seg2 = 1;
a = arduino('COM3');    %Select a COM for arduino
a.pinMode(8,'output');  %Source of Light in pin 8
a.digitalWrite(8,1);    %Turn on Light
a.servoAttach(3);       %Servo-Motor in pin 3
% UIWAIT makes beta1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = beta1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in bot_branco.
function bot_branco_Callback(hObject, eventdata, handles)
% hObject    handle to bot_branco (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %This sub is for solvent data.

global sensor;
global a;
global compOnda;    
global xespectro;
global ybranco;
global servo;
global sensor1;
global i;
global seg;
sensor = 0;
sensor1 = 1:20;
xespectro = 400:3:700;
ybranco = 0:100;
compOnda = 1;
servo = 125;    %Put the Mirror Prism on color that represent the first violet, near to 400nm of wavelengths
a.servoWrite(3,servo);
pause(4);
while compOnda <= 101       %The condition ends when the last red is selected, near to 700 nm of wavelengths
    i = 1;
    a.servoWrite(3,servo); %Spin the Mirror Prism on 3 wavelengths
    pause(1);
    while i <= 20
        sensor1(i) = ((a.analogRead(1))/1000)*4; %Because of low sensitivity of the sensor, it makes up an average of 20 readings at the same point
        i = i + 1;
    end
    sensor = mean(sensor1);
    ybranco(compOnda) = roundn(sensor, -3); %Defines the value of the solvent absorption in all visible wavelengths
    compOnda = compOnda + 1;
    servo = servo - 1;
end
seg = 10;
            

% --- Executes on button press in bot_substancia.
function bot_substancia_Callback(hObject, eventdata, handles)
% hObject    handle to bot_substancia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %This sub is for the electromagnetic absorbance spectrum of substance

global sensor;
global a;
global compOnda;
global xespectro;
global ybranco;
global yamostra;
global servo;
global sensor1;
global i;
global seg;
if seg ~= 10
    errordlg('Read the solvent first!!', 'Solvent no data');
else
    
sensor1 = 1:20;
sensor = 0;
compOnda = 1;
servo = 125;        %Put the Mirror Prism on color that represent the first violet, near to 400nm of wavelengths
a.servoWrite(3,servo);
pause(4);
while compOnda <= 101   %The condition ends when the last red is selected, near to 700 nm of wavelengths
   i = 1;
    a.servoWrite(3,servo); %Spin the Mirror Prism on 3 wavelengths
    pause(1);
   while i <= 20
        sensor1(i) = ((a.analogRead(1))/1000)*4;    %Because of low sensitivity of the sensor, it makes up an average of 20 readings at the same point
        i = i + 1;
    end
    sensor = mean(sensor1);   
    yamostra(compOnda) = roundn(sensor, -3) - ybranco(compOnda); %Defines the value of the substance absorption in all visible wavelengths without the solvent datas
    if yamostra(compOnda) < 0
        yamostra(compOnda) = 0;
    end
    compOnda = compOnda + 1;
    servo = servo - 1;
end

    %Begin the graphic of electromagnetic absorbance spectrum of substance
grid on;    
plot(handles.axes1,xespectro,yamostra) %in axis x is there wavelength, in axis y, absorbance
ylim([0 2])
xlabel('Wavelengths')
ylabel('Absorbance')
title('Absorbance Spectrum')
hold off;
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1



function nomeamostra_Callback(hObject, eventdata, handles)
% hObject    handle to nomeamostra (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nomeamostra as text
%        str2double(get(hObject,'String')) returns contents of nomeamostra as a double


% --- Executes during object creation, after setting all properties.
function nomeamostra_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nomeamostra (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in salvargrafico.
function salvargrafico_Callback(hObject, eventdata, handles)
% hObject    handle to salvargrafico (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %This sub saves the data in a Excel file

global xespectro;
global yamostra;
global nome;
nome = get(handles.nomeamostra,'String');
if isempty(nome)
    errordlg('Give a name for substance!', 'Name no data');
else
    filename = nome;
    xlRange = 'A1:A101';
    xlswrite(filename,xespectro',xlRange);
    ylRange = 'B1:B101';
    xlswrite(filename,yamostra',ylRange);
    
end



function compondaA_Callback(hObject, eventdata, handles)
% hObject    handle to compondaA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of compondaA as text
%        str2double(get(hObject,'String')) returns contents of compondaA as a double


% --- Executes during object creation, after setting all properties.
function compondaA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to compondaA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in leramostra.
function leramostra_Callback(hObject, eventdata, handles)
% hObject    handle to leramostra (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    %This class receve the absorbance in a specific wavelength

global a;
global sensor;
global alfa;
global comp;
global ybranco;
global valor;
global sensor2;
global comp2;
global i;
global seg;
global seg2;
    
sensor2 = 0;
valor = 1:20;
i = 1;
alfa = str2num(get(handles.compondaA,'String')); %Read the wavelength set by the user


if seg ~= 10
    errordlg('Read the solvent first!!', 'Solvent no data');
elseif isempty(alfa)
    errordlg('Set the wavelength!!', 'Wavelength no data');
else

    if alfa > 400                                   %Compares the value is within the range of visible wavelength
        if alfa < 700
        
            comp = int64(125 - (alfa - 400)/3);            %Converts the value to degrees of rotation for the servomotor
            comp2 = int64((alfa - 400)/3);
            if comp2 < 1
                comp2 = 1;
            end
            a.servoWrite(3,comp);                   %Positioning servo motor at a wavelength selected by the user
            pause(2);
            while i <= 20
                valor(i) = ((a.analogRead(1))/1000)*4;
                i = i + 1;
            end
            sensor2 = mean(valor);
            sensor = roundn(sensor2, -3) - ybranco(comp2);
            set(handles.abs,'String', roundn(sensor, -3));    %Show the value for user
        end
    else
        errordlg('Wavelength off limits! Set between 400 and 700 nm!', 'Wavelength Error');
    end
end
seg2 = 10;




function regA_Callback(hObject, eventdata, handles)
% hObject    handle to regA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of regA as text
%        str2double(get(hObject,'String')) returns contents of regA as a double


% --- Executes during object creation, after setting all properties.
function regA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to regA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function regB_Callback(hObject, eventdata, handles)
% hObject    handle to regB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of regB as text
%        str2double(get(hObject,'String')) returns contents of regB as a double


% --- Executes during object creation, after setting all properties.
function regB_CreateFcn(hObject, eventdata, handles)
% hObject    handle to regB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in calcconc.
function calcconc_Callback(hObject, eventdata, handles)
% hObject    handle to calcconc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    
    %This class calculates the concentration from the absorbance and logarithmic regression
    
    %This code do not calculate the regression!
    
global coefang;
global coeflin;
global absorb;
global concentrac;
global abi;
global coef;
abi = get(handles.abs,'String');
coef = get(handles.regA,'String');
absorb = str2double(get(handles.abs,'String')); %Read the absorbance
coefang = str2double(get(handles.regA,'String'));   %Read the coefficient with ln(x)
coeflin = str2double(get(handles.regB,'String'));   %Read the other coefficient

if isempty(abi)
    errordlg('Read the Absorbance first!!', 'Absorbance no data')
elseif isempty(coef)
    errordlg('Enter the data of the logarithmic regression!', 'Regression no data')
else
    
concentrac = exp((absorb - coeflin)/coefang);       %Calculates the concentration from the absorbance
set(handles.concent,'String', concentrac);      %Show the value for user

end

% --- Executes during object creation, after setting all properties.
function concent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to concent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function abs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to abs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
